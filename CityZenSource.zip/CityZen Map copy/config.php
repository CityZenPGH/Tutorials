<?php
$con = new PDO('mysql:host=localhost;port=8889;dbname=CityZen', 'root', 'root');
?>
